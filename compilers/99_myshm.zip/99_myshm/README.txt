Please change Author, copyrights in your code.

To build:
$ make

To clean:
$ make clean

Happy Learning.
