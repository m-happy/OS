Instruction to run and execute the program
(I) for Assgn2-ProcStat-CS17BTECH11018.cpp:
	1 : "for compling the program"
		$  g++ Assgn2-ProcStat-CS17BTECH11018.cpp -o process -lrt
	2 : "to execute the executable file 'process' created"	
		$ ./process <input.txt> output.txt    --input.txt is input file to be given
											  --output.txt is output file generated
(II) For Assgn2-ThStat-CS17BTECH11018.cpp:
	1 : "for comiling the program"
		$ g++ Assgn2-ThStat-CS17BTECH11018.cpp -o thread -lpthread
	2 : "to execute the executable file 'thread' created"
		$ ./thread < input.txt > output.txt     --input.txt is the input file to be given
												--output.txt is the output file generated

(III) Analysis and working of the programs are present in Assgn2-Report-CS17BTECH11018.pdf