Instructions to execute the program :
(I) For dphil-CS17BTECH11018.cpp :
	$ g++ dphil-CS17BTECH11018.cpp -lpthread 
	$ ./a.out
	"dining-log.txt" will be generated.

(II) Create "input.txt" first and then compile and run.
