Instructions to execute the program :
(I) For rw-CS17BTECH11018.cpp :
	$ g++ rw-CS17BTECH11019.cpp -lpthread 
	$ ./a.out
	"RW-LOG.txt" will be generated.
(II) For frw-CS17BTECH11018.cpp :
	$ g++ frw-CS17BTECH11018.cpp -lpthread
	$ ./a.out
	"FRW-LOG.txt" will be generated

NOTE : Complier may give some warning(ignore them).