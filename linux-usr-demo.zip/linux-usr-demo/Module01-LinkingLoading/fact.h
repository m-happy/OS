#ifndef __FACT_H__
#define __FACT_H__

int fact(int n);

#endif
