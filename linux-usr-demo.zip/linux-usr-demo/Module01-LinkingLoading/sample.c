#include <stdio.h>

int main()
{
	char ch;
	printf("Hello\n");
	scanf("%c", &ch);
	return 0;
}

